package com.example.BabaFoodServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabaFoodServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
