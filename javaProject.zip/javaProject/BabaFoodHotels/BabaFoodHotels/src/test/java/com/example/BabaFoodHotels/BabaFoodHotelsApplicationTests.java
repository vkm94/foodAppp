package com.example.BabaFoodHotels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabaFoodHotelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
