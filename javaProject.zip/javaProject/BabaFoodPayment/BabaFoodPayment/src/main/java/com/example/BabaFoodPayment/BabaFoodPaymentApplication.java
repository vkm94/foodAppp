package com.example.BabaFoodPayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BabaFoodPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BabaFoodPaymentApplication.class, args);
	}

}
